﻿using System.Collections.Generic;

namespace ConsoleApp1
{
    public class CustomerOrder
    {
        public int ID { get; set; }
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
        public string Tax { get; set; }
        public decimal Total { get; set; }
    }
}