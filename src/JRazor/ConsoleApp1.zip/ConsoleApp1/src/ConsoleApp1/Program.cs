﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;


namespace ConsoleApp1
{
    public class Program
    {
        public static void Main(string[] args)
        {

            var str = "Hello @Order.Name Welcome to  repository";

            // Generate code for the template
            var razorResult = Generate(str);

            YOYO.AspNetCore.ViewEngine.Razor.RoslynCompileService ss = new YOYO.AspNetCore.ViewEngine.Razor.RoslynCompileService();

            var type = ss.Compile(razorResult.GeneratedCode);

            if (type == null)
            {
                Console.ReadKey();
                return;
            }

            var template = (OrderInfoTemplateBase)Activator.CreateInstance(type);

            var model = new
            {
                Name = "John Doe",
                Title = "RazorLight",
            };

            var json = Newtonsoft.Json.JsonConvert.SerializeObject(model);

            template.Order = Newtonsoft.Json.JsonConvert.DeserializeObject<System.Dynamic.ExpandoObject>(json);

            var fff = template.GetContent();
        }

        public static Microsoft.AspNetCore.Razor.CodeGenerators.GeneratorResults Generate(string template)
        {
            //准备临时类名，读取模板文件和Razor代码生成器
            string templateType = "OrderInfoTemplateBase";

            var class_name = "c" + Guid.NewGuid().ToString("N");
            var host = new Microsoft.AspNetCore.Razor.RazorEngineHost(new Microsoft.AspNetCore.Razor.CSharpRazorCodeLanguage(), () => new Microsoft.AspNetCore.Razor.Parser.Internal.HtmlMarkupParser())
            {
                DefaultBaseClass = templateType,
                DefaultClassName = class_name,
                DefaultNamespace = "ConsoleApp1",
                GeneratedClassContext =
                                   new Microsoft.AspNetCore.Razor.CodeGenerators.GeneratedClassContext("Execute", "Write", "WriteLiteral", "WriteTo",
                                                             "WriteLiteralTo",
                                                             "RazorViewTemplate.Dynamic", new Microsoft.AspNetCore.Razor.CodeGenerators.GeneratedTagHelperContext())

            };
            host.NamespaceImports.Add("System");
            host.NamespaceImports.Add("System.Dynamic");
            host.NamespaceImports.Add("System.Linq");
            host.NamespaceImports.Add("System.Collections.Generic");

            var engine = new Microsoft.AspNetCore.Razor.RazorTemplateEngine(host);

            return engine.GenerateCode(new StringReader(template));
        }


        private static Type Compile(string compilationContent)
        {
            Microsoft.CodeAnalysis.SyntaxTree syntaxTree = Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree.ParseText(compilationContent);

            string assemblyName = Path.GetRandomFileName();

            Assembly entryAssembly = Assembly.GetEntryAssembly();

            string runtimePath = System.IO.Path.GetDirectoryName(typeof(object).GetTypeInfo().Assembly.Location);

            string mscorlibFile = Path.Combine(runtimePath, "mscorlib.dll");

            List<Microsoft.CodeAnalysis.MetadataReference> references = new List<Microsoft.CodeAnalysis.MetadataReference>();

            if (File.Exists(mscorlibFile))
                references.Add(Microsoft.CodeAnalysis.MetadataReference.CreateFromFile(mscorlibFile));
            else
                references.Add(Microsoft.CodeAnalysis.MetadataReference.CreateFromFile(Path.Combine(runtimePath, "mscorlib.ni.dll")));


            references.Add(Microsoft.CodeAnalysis.MetadataReference.CreateFromFile(typeof(System.Object).GetTypeInfo().Assembly.Location));
            references.Add(Microsoft.CodeAnalysis.MetadataReference.CreateFromFile(typeof(System.Dynamic.DynamicObject).GetTypeInfo().Assembly.Location));
            references.Add(Microsoft.CodeAnalysis.MetadataReference.CreateFromFile(entryAssembly.Location));

            Microsoft.CodeAnalysis.CSharp.CSharpCompilation compilation = Microsoft.CodeAnalysis.CSharp.CSharpCompilation.Create(assemblyName, new[] { syntaxTree }, references, new Microsoft.CodeAnalysis.CSharp.CSharpCompilationOptions(Microsoft.CodeAnalysis.OutputKind.DynamicallyLinkedLibrary));

            using (var ms = new MemoryStream())
            {
                Microsoft.CodeAnalysis.Emit.EmitResult result = compilation.Emit(ms);

                if (!result.Success)
                {
                    System.Collections.Generic.IEnumerable<Microsoft.CodeAnalysis.Diagnostic> failures = result.Diagnostics.Where(diagnostic =>
                        diagnostic.IsWarningAsError ||
                        diagnostic.Severity == Microsoft.CodeAnalysis.DiagnosticSeverity.Error);

                    foreach (Microsoft.CodeAnalysis.Diagnostic diagnostic in failures)
                    {
                        Console.Error.WriteLine("{0}: {1}", diagnostic.Id, diagnostic.GetMessage());
                    }

                    return null;
                }
                else
                {
                    ms.Seek(0, SeekOrigin.Begin);
                    Assembly assembly = System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromStream(ms);

                    return assembly.GetType();
                }
            }
        }
    }
}
