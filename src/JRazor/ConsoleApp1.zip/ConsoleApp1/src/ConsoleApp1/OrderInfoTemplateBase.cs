﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Dynamic;

namespace ConsoleApp1
{
    public abstract class OrderInfoTemplateBase
    {
        private System.Text.StringBuilder buffer;
        protected OrderInfoTemplateBase()
        {
            Order = new System.Dynamic.ExpandoObject();
        }
        public dynamic Order { get; set; }

        public abstract Task Execute();

        public virtual void Write(object value)
        {
            WriteLiteral(value);
        }

        public virtual void WriteLiteral(object value)
        {
            buffer.Append(value);
        }

        public string GetContent()
        {
            buffer = new System.Text.StringBuilder(1024);
            Execute();
            return buffer.ToString();
        }
    }
}
